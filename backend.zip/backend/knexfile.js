const path = require('path');
const fs = require('fs');
require('dotenv').config();

module.exports = {
  development: {
    client: 'pg',
    connection: process.env.DATABASE_URL,
    migrations: { directory: path.join(__dirname, 'migrations') },
    seeds:      { directory: path.join(__dirname, 'seeders') },
  ssl: { ca: fs.readFileSync('ca.crt') }
  }
};
