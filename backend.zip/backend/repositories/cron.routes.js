const express = require('express');
const ctrl = require('../controllers/cron.controller');


const router = express.Router();


router.get('/agendamentos/ativos', ctrl.listAgendamentosAtivos);
router.get('/jobs', ctrl.listarExecucoes);
router.post('/agendamentos/:id/run', ctrl.runNow);


module.exports = router;